window.NA_CONFIG={timezone:"Asia/Kolkata",startHour:10,endHour:22,supportUrl:"https://t.me/aalok0602",plannerUrl:"planner/NEET-AARAMBH-Test-Planner.pdf"};
