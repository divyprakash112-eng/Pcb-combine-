window.NA_TESTS=[
  {
    "id": 1,
    "date": "2026-10-11",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [
        "Mathematical Tools",
        "Units and Measurements",
        "Motion in a Straight Line",
        "Vectors"
      ],
      "Chemistry": [
        "Some Basic Concept of Chemistry",
        "Redox Reaction",
        "Solutions"
      ],
      "Botany": [
        "Cell – The Unit of Life",
        "Cell Cycle and Cell Division"
      ],
      "Zoology": [
        "Structural Organization in Animals",
        "Breathing and Exchange of Gases"
      ]
    }
  },
  {
    "id": 2,
    "date": "2026-10-18",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [
        "Motion in a Plane"
      ],
      "Chemistry": [
        "Thermodynamics & Thermochemistry",
        "Chemical Equilibrium",
        "Ionic Equilibrium"
      ],
      "Botany": [
        "The Living World",
        "Biological Classification"
      ],
      "Zoology": [
        "Body Fluids and Circulation"
      ]
    }
  },
  {
    "id": 3,
    "date": "2026-11-01",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 4,
    "date": "2026-11-08",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 5,
    "date": "2026-11-22",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 6,
    "date": "2026-11-29",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 7,
    "date": "2026-12-13",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 8,
    "date": "2026-12-20",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 9,
    "date": "2027-01-03",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 10,
    "date": "2027-01-10",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 11,
    "date": "2027-01-24",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 12,
    "date": "2027-01-31",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 13,
    "date": "2027-02-14",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 14,
    "date": "2027-02-28",
    "type": "part",
    "available": false,
    "syllabus": {
      "Physics": [],
      "Chemistry": [],
      "Botany": [],
      "Zoology": []
    }
  },
  {
    "id": 15,
    "date": "2027-03-07",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 16,
    "date": "2027-03-14",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 17,
    "date": "2027-03-21",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 18,
    "date": "2027-03-28",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 19,
    "date": "2027-04-04",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 20,
    "date": "2027-04-11",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 21,
    "date": "2027-04-18",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 22,
    "date": "2027-04-25",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  },
  {
    "id": 23,
    "date": "2027-04-30",
    "type": "full",
    "available": false,
    "syllabus": {
      "Physics": [
        "Full syllabus"
      ],
      "Chemistry": [
        "Full syllabus"
      ],
      "Botany": [
        "Full syllabus"
      ],
      "Zoology": [
        "Full syllabus"
      ]
    }
  }
];
