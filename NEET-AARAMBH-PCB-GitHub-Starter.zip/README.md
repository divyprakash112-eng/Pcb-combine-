# NEET AARAMBH — PCB Combined Test Series

Static GitHub Pages site: HTML, CSS, Vanilla JavaScript, JSON.

## Publish
1. Create GitHub repository `neet-aarambh-pcb`.
2. Upload all files in this project to the repository root.
3. Settings → Pages → Deploy from a branch → `main` → `/(root)` → Save.

## Add a CBT
Replace `tests/test-XX/index.html` with that test's standalone CBT HTML, then change its `available: false` to `available: true` in `assets/js/tests.js`.

## Important limitation
GitHub Pages is public static hosting. Hiding a link until 10 AM is not true access control; anyone who knows a public file URL may be able to open it early. The CBT itself must implement result display.

The test schedule is transcribed from the PCB Combined planner. Syllabus detail is currently entered for Tests 01 and 02; later part-syllabus tests show a prompt to consult the planner until their detailed syllabus is filled in.

